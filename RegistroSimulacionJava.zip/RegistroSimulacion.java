import java.io.IOException;
import java.nio.file.*;

public class RegistroSimulacion {
    public static void main(String[] args) {
        Path carpeta = Paths.get("config");
        Path archivo = carpeta.resolve("parametros.txt");

        String contenido = """
                Tiempo de ciclo: 55.8 segundos
                Velocidad de línea: 1.2 m/s
                Número de estaciones: 8
                """;

        try {
            // Crear carpeta si no existe
            if (!Files.exists(carpeta)) {
                Files.createDirectories(carpeta);
                System.out.println("Carpeta 'config/' creada.");
            }

            // Escribir archivo
            Files.write(archivo, contenido.getBytes());
            System.out.println("Archivo 'parametros.txt' creado y escrito.");

            // Validar existencia del archivo
            if (Files.exists(archivo)) {
                System.out.println("El archivo fue creado correctamente.");
            }

            // Leer y mostrar contenido
            String leido = Files.readString(archivo);
            System.out.println("Contenido del archivo:");
            System.out.println(leido);

        } catch (IOException e) {
            System.err.println("Error al manejar el archivo: " + e.getMessage());
        }
    }
}
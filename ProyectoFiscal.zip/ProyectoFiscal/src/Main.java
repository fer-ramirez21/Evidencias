public class Main {
    public static void main(String[] args) {
        // Crear una declaración de impuestos
        DeclaracionImpuestos declaracion = new DeclaracionImpuestos("ABC123456T9", 15000.00);

        // Crear una cuenta fiscal
        CuentaFiscal cuenta = new CuentaFiscal("ABC123456T9", 20000.00);

        // Mostrar la información
        System.out.println("Declaración de Impuestos:");
        System.out.println("RFC: " + declaracion.getRfcContribuyente());
        System.out.println("Monto Declarado: " + declaracion.getMontoDeclarado());

        System.out.println("\nCuenta Fiscal:");
        System.out.println("RFC: " + cuenta.getRfc());
        System.out.println("Saldo Disponible: " + cuenta.getSaldoDisponible());

        // Validar si el RFC coincide
        boolean coincide = cuenta.validarRFC(declaracion);
        System.out.println("\n¿RFC Coincide?: " + (coincide ? "Sí" : "No"));
    }
}
public class DeclaracionImpuestos {
    private String rfcContribuyente;
    private double montoDeclarado;

    public DeclaracionImpuestos(String rfcContribuyente, double montoDeclarado) {
        this.rfcContribuyente = rfcContribuyente;
        this.montoDeclarado = montoDeclarado;
    }

    public String getRfcContribuyente() {
        return rfcContribuyente;
    }

    public double getMontoDeclarado() {
        return montoDeclarado;
    }
}
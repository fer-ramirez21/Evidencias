public class SistemaGPS {
    public void localizar() {
        System.out.println("Localizando posición actual...");
    }
}
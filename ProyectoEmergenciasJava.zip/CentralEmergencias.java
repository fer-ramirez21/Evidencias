public class CentralEmergencias {
    public static void main(String[] args) {
        Ambulancia ambulancia = new Ambulancia("Ambulancia 1", new Operador("Carlos"));
        Patrulla patrulla = new Patrulla("Patrulla 2", new Operador("Luisa"));
        UnidadBomberos bomberos = new UnidadBomberos("Unidad Bomberos 3", new Operador("Miguel"));

        ambulancia.iniciarOperacion();
        System.out.println("--------------------");
        patrulla.iniciarOperacion();
        System.out.println("--------------------");
        bomberos.iniciarOperacion();
    }
}
public class Sirena {
    public void activarSirena() {
        System.out.println("Sirena activada.");
    }
}
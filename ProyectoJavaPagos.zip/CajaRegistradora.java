public class CajaRegistradora {
    public static void main(String[] args) {
        MetodoPago[] pagos = {
            new PagoEfectivo(50),
            new PagoTarjeta(100, 150),
            new PagoTarjeta(200, 100),
            new PagoTransferencia(75, true),
            new PagoTransferencia(60, false)
        };

        for (MetodoPago pago : pagos) {
            if (pago instanceof Autenticable) {
                Autenticable metodo = (Autenticable) pago;
                if (metodo.autenticar()) {
                    pago.procesarPago();
                    pago.mostrarResumen();
                } else {
                    System.out.println("Autenticación fallida para: " + pago.getClass().getSimpleName());
                    System.out.println("-----------------------");
                }
            }
        }
    }
}
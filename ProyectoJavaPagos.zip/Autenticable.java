public interface Autenticable {
    boolean autenticar();
}
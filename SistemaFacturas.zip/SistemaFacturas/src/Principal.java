public class Principal {
    public static void main(String[] args) {
        // Crear facturas
        Factura facturaConRFC = new Factura(2500.75, "Servicios de consultoría", "RFC123456X");
        Factura facturaSinRFC = new Factura(1300.50, "Venta de productos", null);

        // Imprimir resumen
        System.out.println("Factura con RFC:");
        System.out.println(facturaConRFC.getResumen());

        System.out.println("\nFactura sin RFC:");
        System.out.println(facturaSinRFC.getResumen());
    }
}
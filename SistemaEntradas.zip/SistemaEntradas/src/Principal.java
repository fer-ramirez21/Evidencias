public class Principal {
    public static void main(String[] args) {
        // Usando la clase tradicional
        Entrada entrada1 = new Entrada("Obra de Teatro", 450.0);
        Entrada entrada2 = new Entrada("Concierto de Rock", 850.0);

        System.out.println("Entradas con clase tradicional:");
        entrada1.mostrarInformacion();
        entrada2.mostrarInformacion();

        // Usando record (Java moderno)
        Entrada_Record entradaRecord = new Entrada_Record("Festival de Jazz", 600.0);
        System.out.println("\nEntrada con record:");
        entradaRecord.mostrarInformacion();
    }
}
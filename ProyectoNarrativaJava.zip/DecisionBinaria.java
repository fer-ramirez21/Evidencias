import java.util.Scanner;

public class DecisionBinaria implements LogicaDecision {
    @Override
    public boolean tomarDecision() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("¿Quieres entrar a la cueva? (s/n): ");
        String entrada = scanner.nextLine();
        return entrada.equalsIgnoreCase("s");
    }
}
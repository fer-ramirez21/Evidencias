public class TransicionSimple implements TransicionHistoria {
    @Override
    public void siguienteEscena() {
        System.out.println("La historia avanza a la siguiente escena...");
    }
}
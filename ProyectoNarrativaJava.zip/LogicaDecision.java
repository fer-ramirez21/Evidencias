public interface LogicaDecision {
    boolean tomarDecision();
}
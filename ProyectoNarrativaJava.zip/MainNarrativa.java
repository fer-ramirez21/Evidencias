public class MainNarrativa {
    private TransicionHistoria transicion;
    private GestorDialogo dialogo;
    private LogicaDecision decision;

    public MainNarrativa(TransicionHistoria transicion, GestorDialogo dialogo, LogicaDecision decision) {
        this.transicion = transicion;
        this.dialogo = dialogo;
        this.decision = decision;
    }

    public void ejecutar() {
        dialogo.mostrarDialogo("Te encuentras frente a una cueva misteriosa.");
        if (decision.tomarDecision()) {
            dialogo.mostrarDialogo("Decides entrar con valentía.");
            transicion.siguienteEscena();
        } else {
            dialogo.mostrarDialogo("Decides dar la vuelta y regresar a casa.");
        }
    }

    public static void main(String[] args) {
        TransicionHistoria transicion = new TransicionSimple();
        GestorDialogo dialogo = new DialogoTexto();
        LogicaDecision decision = new DecisionBinaria();

        MainNarrativa narrativa = new MainNarrativa(transicion, dialogo, decision);
        narrativa.ejecutar();
    }
}
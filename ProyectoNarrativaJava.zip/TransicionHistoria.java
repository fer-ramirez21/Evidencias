public interface TransicionHistoria {
    void siguienteEscena();
}
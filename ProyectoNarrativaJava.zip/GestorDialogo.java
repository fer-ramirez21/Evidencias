public interface GestorDialogo {
    void mostrarDialogo(String texto);
}
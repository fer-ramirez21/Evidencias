public class Principal {
    public static void main(String[] args) {
        // Crear pasajero y vuelo
        Pasajero pasajero1 = new Pasajero("Carlos Pérez", "P12345678");
        Vuelo vuelo1 = new Vuelo("VU123", "Madrid", "14:30");

        // Reservar asiento
        vuelo1.reservarAsiento(pasajero1);

        // Mostrar itinerario
        System.out.println("Itinerario después de reservar:");
        System.out.println(vuelo1.obtenerItinerario());

        // Cancelar reserva
        vuelo1.cancelarReserva();

        // Mostrar itinerario después de cancelar
        System.out.println("\nItinerario después de cancelar:");
        System.out.println(vuelo1.obtenerItinerario());

        // Reservar usando nombre y pasaporte
        vuelo1.reservarAsiento("Laura Gómez", "L98765432");

        // Mostrar itinerario final
        System.out.println("\nItinerario final después de nueva reserva:");
        System.out.println(vuelo1.obtenerItinerario());
    }
}